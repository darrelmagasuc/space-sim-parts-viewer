# Space Sim parts: Godot low-poly GLB set v1

This set contains game-ready low-poly versions of the CAD GLB set v2. It has the same 108 parts (cmd 11, prop 15, tank 11, stage 12, station 14, power 14, rover 13, jet 12, cockpit 6) as 226 GLB variants, plus the 2 reference assemblies. The folder layout, file names, axes, origins and attach nodes are identical to `space_sim_glb_v2`, so you can swap a v2 file for the low-poly one without changing any offsets. Full rules are in `CONVENTIONS.md` (authoritative).

## What's different from v2
- **Triangle budget:** at most **5,000 triangles** per variant. Targets are about 1,200 for parts up to 0.8 m, 2,500 up to 1.6 m and 4,000 above that. Across the 226 variants the range is 72 to 4,984 triangles, the mean is about 2,680 and the total is 605 k (v2 CAD: 1.96 M). Each part was re-tessellated from the STEP source per component. Struts and trusses were rebuilt as 6-sided prisms, freeform parts were decimated, and flat faces were merged (limited dissolve). Hard edges are split at CAD face boundaries, and a WeightedNormal pass gives clean shading.
- **Size accuracy:** every variant's bounding box is within 1% of the CAD GLB (worst case 0.33%). Node positions and directions match `nodes.json` exactly: 569 of 569 nodes checked.
- **Materials:** each GLB uses a shared PBR library (metallic-roughness), so a material has the same name in every file. You can replace it project-wide in Godot, for example with *Import → Materials → External*, or by mapping the name to your own `.tres`. The library is listed below, and its source is in `library/materials.json`.
- **Textures:** small tiling detail maps are embedded as JPEG: 256 px, or 512 px for MLI. They're greyscale albedo multiplied by the base colour factor, plus tangent-space normal maps. The originals are in `library/textures/`. UVs are cylindrical for axisymmetric components and box-projected otherwise, in world-scale metres (`tile_m` = metres per repeat), so texel density stays consistent between parts.
- **Glass** (`glass_tinted`) is `alphaMode: BLEND` and double-sided. In Godot it imports as a transparent `StandardMaterial3D`.
- File sizes are 19 to 380 KB per variant (about 29 MB in total), mostly from the embedded textures.

## Layout
- `<category>/<variant>.glb`: one file per size or pose variant, with the same names as v2.
- `<category>/<id>.nodes.json`: per part, the node list for every variant, dims, bbox, `primary` variant and `state`. These are unchanged from v2.
- `assemblies/`: `gravity_ring_assembly.glb` (station09 hub + 6 × station10 spokes + 12 × station11 segments + station13 despun core) and `counter_rotating_assembly.glb` (station12 + 2 rings), plus `assemblies.json` (bboxes, triangle counts). They're built from the low-poly parts with **instanced meshes**: each repeated part is stored once and referenced by several nodes, so Godot imports them as shared `Mesh` resources. Assemblies are exempt from the 5,000 cap (about 67 k and 123 k triangles). They're for reference and layout; a build ships from the individual parts.
- `library/`: `materials.json` and `textures/`. These are optional and only needed for re-authoring materials.

## Import basics (same as v2)
- **Y-up, right-handed glTF**, so it drops straight into Godot 4 with no rotation. CAD Z-up was converted as `Godot (X, Y, Z) = CAD (X, Z, −Y)`. Forward/front is +Z, and the stack/flight axis is +Y. For cockpits, the nose is along +Y, the dorsal side +Z and the right side +X.
- **Units are metres** at scale 1.0. Import at scale 1.
- **Origin**: on the stack axis at bbox mid-height. Radial parts use the bbox centre, with the parent on −X and pointing +X. Ground vehicles use the footprint centre, with `node_bottom` on the ground plane. Gravity-ring parts (station09–12) place by rotation about Y only (spoke j: 60j°, segment k: 30k°).
- **Moving parts stay separate meshes**, named by function as in v2 (`wheel_1`, `nozzle_extension`, `rotor_drum`, `canopy`, …), so scripts can animate or jettison them. Pose variants (`_deployed`, `_steer_left`, `_defl_pos`, …) share the default pose's origin.
- **Collision:** the meshes are light enough for `create_trimesh_shape()` on static props. For rigid bodies, prefer `create_convex_shape()` per sub-mesh or simple primitives.

## Node empties
Each GLB contains an empty `Node3D` for every attach node, named as in `nodes.json` (`node_top`, `node_bottom`, `node_side_N`, `node_attach`, `node_port_N`, `node_hatch_N`, `node_wheel_N`, `node_foot`, `node_tool`, `node_payload`). The node's **local +Y points along the node direction**, i.e. the outward normal of the mating face. To snap part B to part A, align B's node so its +Y is opposite to A's node +Y at the same position.

## Material library
| name | metallic | roughness | albedo / normal texture |
|---|---|---|---|
| `mli_gold` | 1.0 | 0.32 | mli_c.jpg / mli_n.jpg |
| `beta_cloth` | 0.0 | 0.9 | cloth_c.jpg / cloth_n.jpg |
| `tile_black` | 0.0 | 0.85 | tile_c.jpg / tile_n.jpg |
| `tile_white` | 0.0 | 0.8 | tile_c.jpg / tile_n.jpg |
| `aluminium` | 1.0 | 0.33 | mottle_c.jpg / mottle_n.jpg |
| `anodised_dark` | 0.8 | 0.45 | — / — |
| `paint_white` | 0.0 | 0.5 | — / — |
| `glass_tinted` | 0.0 | 0.05 | — / — (alpha 0.28, blend) |
| `nozzle_copper` | 1.0 | 0.35 | mottle_c.jpg / — |
| `radiator_black` | 0.2 | 0.6 | radiator_c.jpg / radiator_n.jpg |
| `solar_blue` | 0.3 | 0.25 | solar_c.jpg / solar_n.jpg |
| `rubber_tyre` | 0.0 | 0.95 | — / tread_n.jpg |
| `ablator` | 0.0 | 0.9 | char_c.jpg / mottle_n.jpg |
| `paint_grey` | 0.0 | 0.55 | — / — |
| `paint_grey_dark` | 0.0 | 0.55 | — / — |
| `paint_black_matte` | 0.0 | 0.9 | — / — |
| `paint_yellow` | 0.0 | 0.5 | — / — |
| `paint_orange` | 0.0 | 0.8 | — / — |
| `paint_tan` | 0.0 | 0.7 | — / — |
| `paint_green` | 0.0 | 0.7 | — / — |
| `seat_fabric` | 0.0 | 0.9 | cloth_c.jpg / cloth_n.jpg |
| `titanium` | 1.0 | 0.4 | mottle_c.jpg / mottle_n.jpg |
| `carbon` | 0.1 | 0.4 | — / — |
| `rcc_grey` | 0.0 | 0.9 | char_c.jpg / mottle_n.jpg |
| `regolith` | 0.0 | 0.9 | char_c.jpg / mottle_n.jpg |
| `radiator_white` | 0.0 | 0.5 | radiator_c.jpg / radiator_n.jpg |
| `nozzle_hot` | 1.0 | 0.5 | mottle_c.jpg / — |
| `steel_dark` | 1.0 | 0.45 | mottle_c.jpg / mottle_n.jpg |
| `nozzle_gold` | 1.0 | 0.3 | mottle_c.jpg / — |
| `nozzle_steel` | 1.0 | 0.3 | mottle_c.jpg / mottle_n.jpg |
| `solar_bronze` | 0.3 | 0.25 | solar_c.jpg / solar_n.jpg |

See `CONVENTIONS.md` for the stack diameters, slot classes and variant/pose suffixes. They're unchanged from v2.
