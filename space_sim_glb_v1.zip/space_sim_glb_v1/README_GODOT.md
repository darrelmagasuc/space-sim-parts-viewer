# Space Sim parts — Godot GLB set v1

102 parts (cmd 11, prop 15, tank 11, stage 12, station 14, power 14, rover 13, jet 12) as 216 GLB variants, plus 2 reference assemblies. Full rules: `CONVENTIONS.md` (authoritative).

## Layout
- `<category>/<variant>.glb`: one file per size / pose variant.
- `<category>/<id>.nodes.json`: per part, the node list for every variant, dims, bbox, `primary` variant and `state`.
- `assemblies/`: `gravity_ring_assembly.glb` (station09 hub + 6 × station10 spokes + 12 × station11 segments + station13 despun core) and `counter_rotating_assembly.glb` (station12 + 2 rings), plus `assemblies.json` (bboxes). They're for reference/layout; build ships from the individual parts.

## Import basics
- **Y-up, right-handed glTF**, so it drops straight into Godot 4 (no rotation). CAD Z-up was converted as `Godot (X, Y, Z) = CAD (X, Z, −Y)`. Forward/front = +Z, stack/flight axis = +Y.
- **Units: metres**, scale 1.0. Import at scale 1.
- **Origin**: on the stack axis at bbox mid-height. Radial parts use the bbox centre, parent on −X, pointing +X. Ground vehicles: footprint centre, `node_bottom` on the ground plane. Gravity-ring parts (station09–12): hub axis in the ring plane, so ring pieces place by rotation about Y only (spoke j: 60j°, segment k: 30k°).
- **Materials**: simple PBR colours per sub-mesh; `glass` is alpha-blended and double-sided.

## Node empties
Each GLB contains an empty `Node3D` for every attach node, named as in `nodes.json` (`node_top`, `node_bottom`, `node_side_N`, `node_attach`, `node_port_N`, `node_hatch_N`, `node_wheel_N`, `node_foot`, `node_tool`, `node_payload`). The node's **local +Y points along the node direction**, i.e. the outward normal of the mating face. To snap part B to part A, align B's node so its +Y is opposite to A's node +Y at the same position. Sub-meshes are named by function (`wheel_1`, `nozzle_extension`, `rotor_drum`, …) so scripts can animate or jettison them.

## Stack diameters
| class | diameter |
|---|---|
| XS | 0.625 m |
| S | 1.25 m |
| M | 2.5 m |
| L | 3.75 m (4.2 m hulls use L rings) |
| XL | 5.0 m |
| XXL | 7.5 m |

Adapters are named top class first (`_m_l`). Wings and control surfaces use shape/size labels (`swept-M`, `elevon-S`, …). The slot-mounted parts use size `slot`.

## Slot classes (grid unit 0.5 × 0.5 × 0.6 m, W × D × H)
| class | units | envelope | volume | examples |
|---|---|---|---|---|
| Small | 1 | 0.5 × 0.5 × 0.6 m | 0.15 m³ | tank08, rover07, power04, power05 M (power05 S = half height) |
| Medium | 2 × 2 × 1 | 1.0 × 1.0 × 0.6 m | 0.6 m³ | power13, power05 L |
| Rack | 2 × 2 × 3 | 1.0 × 1.0 × 1.8 m | 1.8 m³ (pressurised only) | power12 |

Slot items mount by `node_bottom` (centre of the bottom face) and stay inside the envelope.

## Variant / pose suffixes
File name = `<id>_<short>[_<size>][_<pose>]`, e.g. `tank00_kerolox_m`, `station02_b330_deployed`.
- Size suffix only when a part has several sizes. Check `primary` in nodes.json for the default.
- The default pose has no suffix (`state` = `flight`, or `stowed` for deployables). Other poses: `_deployed`, `_stowed` (when the default is deployed), `_steer_left`, `_susp_up`, `_arm_deployed`, `_digging`, `_ab` (afterburner), `_reverser`, `_spike_aft`, `_defl_pos` / `_defl_neg` (±25° about the hinge).
- **All poses share the default pose's origin**, so swapping meshes needs no offset. Pose files are reference key-frames; the moving pieces are also separate sub-meshes you can animate directly.
